<div id="foot">
     　          <p>Copyright &copy; <?php bloginfo('name');  ?> All rights reserved</p> 

     </div>     


  </body>
</html>
