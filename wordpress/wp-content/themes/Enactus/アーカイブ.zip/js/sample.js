$(function(){
        $('#container',".postbg").masonry({
                itemSelector: '.post',
                columnWidth: 270,
                isAnimated:true,
        });
});

